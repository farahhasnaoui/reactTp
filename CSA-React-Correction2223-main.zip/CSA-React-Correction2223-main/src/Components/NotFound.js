import React from "react";
import notfound from "../assets/images/notfound.jfif";
function NotFound() {
  return <img src={notfound} width="100%" height="500" />;
}

export default NotFound;
